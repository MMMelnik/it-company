﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace it_company.Models
{
    class DataContext : DbContext
    {
        public DataContext()
            : base("DbConnection")
        { }

        public DbSet<User> Users { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<Task> Tasks { get; set; }
        public DbSet<Department> Departments { get; set; }
    }
}
