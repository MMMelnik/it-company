﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using System.Windows;
using it_company.Models;
using it_company.Repository;
using System.Windows.Controls;

namespace it_company.ViewModels
{
    public class RegistrationViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string prop)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }

        public event EventHandler Closing;

        public bool Validate = false;

        RelayCommand _register;
        RelayCommand _back;
        RelayCommand _exit;

        string _fName;
        string _lName;
        string _email;
        
        //public string FName
        //{
        //    get { return _fName; }
        //    set
        //    {
        //        _fName = value;
        //        OnPropertyChanged(nameof(FirstName));
        //    }
        //}

        //public string Name
        //{
        //    get { return _name; }
        //    set
        //    {
        //        _name = value;
        //        OnPropertyChanged(nameof(Name));
        //    }
        //}

        //public string Surname
        //{
        //    get { return _surname; }
        //    set
        //    {
        //        _surname = value;
        //        OnPropertyChanged(nameof(Surname));
        //    }
        //}

        //public string Password
        //{
        //    get { return _password; }
        //    set
        //    {
        //        _password = value;
        //        OnPropertyChanged(nameof(Password));
        //    }
        //}
        //public string RepeatPassword
        //{
        //    get { return _repeatPassword; }
        //    set
        //    {
        //        _repeatPassword = value;
        //        OnPropertyChanged(RepeatPassword);
        //    }
        //}
        //public string this[string columnName]
        //{
        //    get
        //    {
        //        string message = string.Empty;

        //        switch (columnName)
        //        {

        //            case "RepeatPassword":
        //                if (!Validation.ValidatePassRepeat(Password, RepeatPassword))
        //                    message = "Пароли не совпадают";
        //                break;
        //        }

        //        Validate = Validation.ValidatePassRepeat(Password, RepeatPassword);

        //        return message;
        //    }
        //}

        //public RelayCommand Register
        //{
        //    get
        //    {
        //        return _register ??
        //            (_register = new RelayCommand(o =>
        //            {
        //                if (!Validate)
        //                {
        //                    MessageBox.Show("Поля заполнены не верно", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);
        //                    return;
        //                }


        //                using (DataContext db = new DataContext())
        //                {
        //                    AccountsRepository accountsRepository = new AccountsRepository(db);


        //                    Account _acc = new Account()
        //                    {
        //                        Login = this.Login,
        //                        Name = this.Name,
        //                        Surname = this.Surname,
        //                        Password = this.Password,
        //                        Admin = false
        //                    };

        //                    accountsRepository.Add(_acc);
        //                    db.SaveChanges();

        //                    MessageBox.Show($" {_acc.Name} ", "Вы успешно зарегестрировались", MessageBoxButton.OK, MessageBoxImage.Information);

        //                    Login _LoginWindow = new Login();
        //                    _LoginWindow.Show();
        //                }

        //                Closing?.Invoke(this, EventArgs.Empty);
        //            }));
        //    }
        //}

        //public RelayCommand Back
        //{
        //    get
        //    {
        //        return _back ??
        //            (_back = new RelayCommand(o =>
        //            {
        //                Login _LoginWindow = new Login();
        //                _LoginWindow.Show();
        //                Closing?.Invoke(this, EventArgs.Empty);
        //            }));
        //    }
        //}

        //public RelayCommand Exit
        //{
        //    get
        //    {
        //        return _exit ??
        //            (_exit = new RelayCommand(o =>
        //            {
        //                Environment.Exit(0);
        //            }));
        //    }
        //}
    }
}
